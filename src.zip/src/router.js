import Vue from 'vue'
import Router from 'vue-router'
//import Home from './views/Home.vue'
import shouye from './views/shouye.vue'
import liebiao from './views/liebiao.vue'
import car from './views/car.vue'
import user from './views/user.vue'
Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    // {
    //   path: '/',
    //   name: 'home',
    //   component: Home
    // },
    // {
    //   path: '/about',
    //   name: 'about',
    //   // route level code-splitting
    //   // this generates a separate chunk (about.[hash].js) for this route
    //   // which is lazy-loaded when the route is visited.
    //   component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    // },
    {
      path: '/shouye',
      name: 'shouye',
      component: shouye
    },
    {
      path: '/liebiao',
      name: 'liebiao',
      component: liebiao
    },
    {
      path: '/car',
      name: 'car',
      component: car
    },
    {
      path: '/user',
      name: 'user',
      component: user
    }
  ]
})
