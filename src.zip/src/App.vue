<template>
<div>
<router-view/>
  <div id="App" class="tab-bar">
    <div class="tab-item" @click="goshouye" :class="{active : this.$route.path==='/shouye'}" alt="" >
      <img :src="this.$route.path ==='/shouye'? require ('./assets/shouye2.png') :require ('./assets/shouye.png')" />
      <span>首页</span>
    </div>
    <div class="tab-item" @click="goliebiao" :class="{active : this.$route.path==='/liebiao'}" alt="" >
      <img :src="this.$route.path ==='/liebiao'? require ('./assets/liebiao2.png') :require ('./assets/liebiao.png')" />
      <span>列表</span>
    </div>
    <div class="tab-item" @click="gocar" :class="{active : this.$route.path==='/car'}" alt="" >
      <img :src="this.$route.path ==='/car'? require ('./assets/gouwuche2.png') :require ('./assets/gouwuche.png')" />
      <span>购物车</span>
    </div>
    <div class="tab-item" @click="gouser" :class="{active : this.$route.path==='/user'}" alt="" >
      <img :src="this.$route.path ==='/user'? require ('./assets/yonghu2.png') :require ('./assets/yonghu.png')"  />
      <span>用户</span>
    </div>
    
  </div>
</div>
</template>

<script>
export default {
  data(){
    return{
      list:[
        {
          path:'/',
          msg:'首页'
        },
        {
          path:'/',
          msg:'列表'
        },
        {
          path:'/',
          msg:'购物车'
        },
        {
          path:'/',
          msg:'用户'
        }
      ]
    }
  },
  methods:{
          goshouye:function(){
            this.$router.push({path:'/shouye'})
          },
          goliebiao:function(){
            this.$router.push({path:'/liebiao'})
          },
          gocar:function(){
            this.$router.push({path:'/car'})
          },
          gouser:function(){
            this.$router.push({path:'/user'})
          }
      }
}
</script>

<style lang="scss">
.tab-bar{
  display: flex;
  position: fixed;
  bottom: 0px;
  width: 100%;
  background: pink;
  justify-content: space-around;
}
.tab-item{
  text-align: center;
  display: inline; 
}
img{
  height: 20px;

}
span{
  display: block;
  bottom: 0px;
}
* {
  padding:0;
  margin: 0;
}
.active{
  color: red;
}
</style>
