<template>
  <div class="car">
    <h1>car</h1>
  </div>
</template>